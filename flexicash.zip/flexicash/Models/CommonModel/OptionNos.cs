﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutoFlexiManagementSystem.Models.CommonModel
{
    public class OptionNos
    {
        public string OptionId { set; get; }
        public string OptionNo { set; get; }
        public double Amount { set; get; }
        public string Details { set; get; }
    }
}