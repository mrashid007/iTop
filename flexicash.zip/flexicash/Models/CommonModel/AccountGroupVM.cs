﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutoFlexiManagementSystem.Models.CommonModel
{
    public class AccountGroupVM
    {
        public string Code { set; get; }
        public string Name { set; get; }
        public string BalanceType { set; get; }
    }
}