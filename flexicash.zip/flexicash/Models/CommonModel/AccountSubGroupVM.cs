﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutoFlexiManagementSystem.Models.CommonModel
{
    public class AccountSubGroupVM
    {
        public string Name { set; get; }
        public string Code { set; get; }
        public long AccountGroupId { set; get; }
    }
}